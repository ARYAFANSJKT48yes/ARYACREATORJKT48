#!/data/data/com.termux/files/usr/bin/bash
apt update && apt upgrade -y
pkg install nodejs git -y
git clone https://github.com/USERNAME/ARYABOT48_GITHUB.git
cd ARYABOT48_GITHUB
npm install
node bot.js
